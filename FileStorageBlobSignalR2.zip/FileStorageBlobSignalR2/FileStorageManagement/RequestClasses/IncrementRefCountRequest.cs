﻿namespace FileStorageManagement.RequestClasses
{
   public class IncrementRefCountRequest
   {
      public int ConsumerId {  get; set; }
   }
}
