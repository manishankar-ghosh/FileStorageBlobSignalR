﻿namespace FileStorageManagement.ResponseClasses
{
   public class FileUploadResponse
   {
      public string? FileGuid {  get; set; }
      public long FileRegistryId { get; set; }
   }
}
